function press(num) {
  document.getElementById("display").value += num;
}

function clearDisplay() {
  document.getElementById("display").value = '';
}

function backspace() {
  let display = document.getElementById("display");
  display.value = display.value.slice(0, -1);
}

function confirmNumpad() {
  const display = document.getElementById("display");
  const value = display.value.trim();
  if (value) {
    console.log("Numpad invoer bevestigd:", value);
    document.getElementById("productA").value = value;
    // Display blijft zichtbaar
  }
  document.getElementById("opmerkingOnder").focus();
}

// Enter op display input
document.getElementById("display").addEventListener("keydown", function(e) {
  if (e.key === "Enter") {
    e.preventDefault();
    confirmNumpad();
  }
});

// Enter-navigatie voor eerste 3 velden
const fields = ["productA", "productB", "productC"];
fields.forEach((id, index) => {
  const input = document.getElementById(id);
  input.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      e.preventDefault();
      if (index < fields.length - 1) {
        document.getElementById(fields[index + 1]).focus();
      } else {
        document.getElementById("display").focus(); // na laatste veld naar numpad
      }
    }
  });
});

// Simuleer formulierverzending
document.getElementById("productForm").addEventListener("submit", function(e) {
  e.preventDefault();
  alert("Formulier verzonden!");
});
